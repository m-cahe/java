select * from studymember;

create table studymember(
id varchar2(100),
pw varchar2(100),
name varchar2(100));



